package com.example.glassbridge;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(GlassBridgeMod.MODID)
public class GlassBridgeMod {
    public static final String MODID = "glassbridge";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Block> BRIDGE_GLASS = BLOCKS.register("bridge_glass",
            () -> new BridgeGlassBlock(BlockBehaviour.Properties.of()
                    .strength(0.3F)
                    .sound(SoundType.GLASS)
                    .noOcclusion()));

    public static final RegistryObject<Item> BRIDGE_GLASS_ITEM = ITEMS.register("bridge_glass",
            () -> new BlockItem(BRIDGE_GLASS.get(), new Item.Properties()));

    public static final RegistryObject<Item> BRIDGE_WAND = ITEMS.register("bridge_wand",
            () -> new BridgeWandItem(new Item.Properties().stacksTo(1)));

    public GlassBridgeMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(BRIDGE_GLASS_ITEM.get());
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(BRIDGE_WAND.get());
        }
    }
}
