package com.example.glassbridge;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/** لوح زجاج: الشكل واحد للنوعين، لكن النوع "fragile" يتحطم عند الوقوف عليه. */
public class BridgeGlassBlock extends Block {
    public static final BooleanProperty FRAGILE = BooleanProperty.create("fragile");

    public BridgeGlassBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FRAGILE, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FRAGILE);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && state.getValue(FRAGILE)
                && entity instanceof Player player && !player.isSpectator()) {
            level.destroyBlock(pos, false); // صوت وجزيئات تحطم الزجاج
        }
        super.stepOn(level, pos, state, entity);
    }

    // لجعل الزجاج شفافًا كالزجاج العادي
    @Override
    public boolean skipRendering(BlockState state, BlockState adjacent, Direction direction) {
        return adjacent.is(this) || super.skipRendering(state, adjacent, direction);
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }
}
