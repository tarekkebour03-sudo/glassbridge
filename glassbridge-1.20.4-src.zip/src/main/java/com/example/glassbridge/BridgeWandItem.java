package com.example.glassbridge;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** عصا تبني الجسر: كل صف فيه لوحان، واحد منهما عشوائيًا هو الهش. */
public class BridgeWandItem extends Item {
    private static final int ROWS = 8;

    public BridgeWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        Direction forward = ctx.getHorizontalDirection();
        Direction side = forward.getClockWise();
        BlockPos start = ctx.getClickedPos().relative(ctx.getClickedFace());
        RandomSource random = level.getRandom();

        for (int i = 0; i < ROWS; i++) {
            BlockPos left = start.relative(forward, i * 2);   // بين كل صفين فراغ بلوك واحد
            BlockPos right = left.relative(side);
            boolean leftIsFragile = random.nextBoolean();
            place(level, left, leftIsFragile);
            place(level, right, !leftIsFragile);
        }
        return InteractionResult.SUCCESS;
    }

    private static void place(Level level, BlockPos pos, boolean fragile) {
        if (level.getBlockState(pos).canBeReplaced()) {
            BlockState state = GlassBridgeMod.BRIDGE_GLASS.get().defaultBlockState()
                    .setValue(BridgeGlassBlock.FRAGILE, fragile);
            level.setBlock(pos, state, 3);
        }
    }
}
